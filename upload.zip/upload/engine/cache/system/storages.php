<?php 

//Storages Configurations

$storages = '{"default":0}';

?>
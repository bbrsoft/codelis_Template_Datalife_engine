<?PHP

define ("DBHOST", "localhost");

define ("DBNAME", "codelist_db");

define ("DBUSER", "root");

define ("DBPASS", "");

define ("PREFIX", "dle");

define ("USERPREFIX", "dle");

define ("COLLATE", "utf8mb4");

define('SECURE_AUTH_KEY', 'fSBz`5>V<MN gp&Hsbv*bsg!`8?e8U%3aZV5Cj|VB7N6Y1tRl~lb/SZbh7khxohp');

$db = new db;

?>